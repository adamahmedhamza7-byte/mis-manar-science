@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (echo ثبّت Python 3.10 أو أحدث مع تفعيل Add Python to PATH & pause & exit /b 1)
py -m venv .venv
call .venv\Scripts\activate
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py app.py
pause
