import os, sqlite3, uuid
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

HERE=os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(HERE,"uploads"),exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get("SECRET_KEY","demo-secret-change-before-real-use")
app.config["MAX_CONTENT_LENGTH"]=20*1024*1024
GRADES=["الصف الرابع الابتدائي","الصف الخامس الابتدائي","الصف السادس الابتدائي","الصف الأول الإعدادي","الصف الثاني الإعدادي","الصف الثالث الإعدادي"]

def db():
 c=sqlite3.connect(os.path.join(HERE,"platform.db")); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
def init():
 with db() as c:
  c.executescript("""
  CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,name TEXT,role TEXT,grade TEXT);
  CREATE TABLE IF NOT EXISTS exams(id INTEGER PRIMARY KEY,title TEXT,grade TEXT,duration INTEGER,created TEXT);
  CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY,exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE,body TEXT,a TEXT,b TEXT,c TEXT,d TEXT,correct TEXT,points REAL);
  CREATE TABLE IF NOT EXISTS homework(id INTEGER PRIMARY KEY,title TEXT,description TEXT,grade TEXT,due TEXT,pdf TEXT,created TEXT);
  CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY,homework_id INTEGER REFERENCES homework(id) ON DELETE CASCADE,student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,answer TEXT,submitted TEXT,UNIQUE(homework_id,student_id));
  CREATE TABLE IF NOT EXISTS results(id INTEGER PRIMARY KEY,exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE,student_id INTEGER REFERENCES users(id) ON DELETE CASCADE,score REAL,total REAL,submitted TEXT);
  """)
  if not c.execute("SELECT id FROM users WHERE username='admin'").fetchone():
   c.execute("INSERT INTO users(username,password,name,role,grade) VALUES(?,?,?,?,?)",("admin",generate_password_hash("admin123"),"ميس منار جمال","admin",""))
  if not c.execute("SELECT id FROM users WHERE username='student'").fetchone():
   c.execute("INSERT INTO users(username,password,name,role,grade) VALUES(?,?,?,?,?)",("student",generate_password_hash("student123"),"طالب تجريبي","student",GRADES[3]))
def need(role):
 def dec(fn):
  @wraps(fn)
  def w(*a,**k):
   if not session.get("uid"): return redirect(url_for("login"))
   if role and session.get("role")!=role: abort(403)
   return fn(*a,**k)
  return w
 return dec
@app.context_processor
def ctx(): return {"me":session.get("name"),"role":session.get("role"),"grades":GRADES,"preview":session.get("preview",False)}
@app.route("/")
def index(): return redirect(url_for("admin") if session.get("role")=="admin" else url_for("student") if session.get("role")=="student" else url_for("login"))
@app.route("/login",methods=["GET","POST"])
def login():
 if request.method=="POST":
  with db() as c: u=c.execute("SELECT * FROM users WHERE username=?",(request.form.get("username","").strip(),)).fetchone()
  if u and check_password_hash(u["password"],request.form.get("password","")):
   session.clear(); session.update(uid=u["id"],username=u["username"],name=u["name"],role=u["role"],grade=u["grade"]); return index()
  flash("بيانات الدخول غير صحيحة","error")
 return render_template("login.html")
@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))
@app.route("/admin")
@need("admin")
def admin():
 with db() as c:
  stats=[c.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0],c.execute("SELECT COUNT(*) FROM exams").fetchone()[0],c.execute("SELECT COUNT(*) FROM homework").fetchone()[0],c.execute("SELECT COUNT(*) FROM results").fetchone()[0]]
  recent=c.execute("SELECT r.*,u.name,e.title FROM results r JOIN users u ON u.id=r.student_id JOIN exams e ON e.id=r.exam_id ORDER BY r.id DESC LIMIT 10").fetchall()
 return render_template("admin.html",stats=stats,recent=recent)
@app.route("/admin/students",methods=["GET","POST"])
@need("admin")
def students():
 if request.method=="POST":
  try:
   with db() as c: c.execute("INSERT INTO users(username,password,name,role,grade) VALUES(?,?,?,?,?)",(request.form["username"].strip(),generate_password_hash(request.form["password"]),request.form["name"].strip(),"student",request.form["grade"]))
   flash("تمت إضافة الطالب")
  except sqlite3.IntegrityError: flash("اسم المستخدم موجود بالفعل","error")
  return redirect(url_for("students"))
 with db() as c: rows=c.execute("SELECT * FROM users WHERE role='student' ORDER BY grade,name").fetchall()
 return render_template("students.html",rows=rows)
@app.post("/admin/students/<int:i>/delete")
@need("admin")
def delstudent(i):
 with db() as c: c.execute("DELETE FROM users WHERE id=? AND role='student'",(i,))
 flash("تم حذف الطالب"); return redirect(url_for("students"))
@app.route("/admin/exams",methods=["GET","POST"])
@need("admin")
def exams():
 if request.method=="POST":
  with db() as c:
   cur=c.execute("INSERT INTO exams(title,grade,duration,created) VALUES(?,?,?,?)",(request.form["title"].strip(),request.form["grade"],max(1,min(240,int(request.form.get("duration",20)))),datetime.now().isoformat(timespec="minutes")))
   eid=cur.lastrowid
   body=request.form.get("body","").strip()
   vals=[request.form.get(x,"").strip() for x in ["a","b","c","d","correct"]]
   if body and all(vals) and vals[4] in "abcd":
    c.execute("INSERT INTO questions(exam_id,body,a,b,c,d,correct,points) VALUES(?,?,?,?,?,?,?,?)",(eid,body,*vals,float(request.form.get("points",1))))
  flash("تم إنشاء الامتحان"); return redirect(url_for("exams"))
 with db() as c: rows=c.execute("SELECT e.*,COUNT(q.id) n FROM exams e LEFT JOIN questions q ON q.exam_id=e.id GROUP BY e.id ORDER BY e.id DESC").fetchall()
 return render_template("exams.html",rows=rows)
@app.route("/admin/exams/<int:eid>/questions",methods=["GET","POST"])
@need("admin")
def questions(eid):
 with db() as c:
  e=c.execute("SELECT * FROM exams WHERE id=?",(eid,)).fetchone()
  if not e: abort(404)
  if request.method=="POST":
   vals=[request.form.get(x,"").strip() for x in ["a","b","c","d","correct"]]
   if request.form.get("body","").strip() and all(vals) and vals[4] in "abcd":
    c.execute("INSERT INTO questions(exam_id,body,a,b,c,d,correct,points) VALUES(?,?,?,?,?,?,?,?)",(eid,request.form["body"].strip(),*vals,float(request.form.get("points",1))))
    flash("تمت إضافة السؤال")
   else: flash("أكمل بيانات السؤال","error")
   return redirect(url_for("questions",eid=eid))
  qs=c.execute("SELECT * FROM questions WHERE exam_id=?",(eid,)).fetchall()
 return render_template("questions.html",exam=e,qs=qs)
@app.post("/admin/questions/<int:qid>/delete")
@need("admin")
def delquestion(qid):
 with db() as c:
  q=c.execute("SELECT exam_id FROM questions WHERE id=?",(qid,)).fetchone()
  if q: c.execute("DELETE FROM questions WHERE id=?",(qid,))
 return redirect(url_for("questions",eid=q["exam_id"]) if q else url_for("exams"))
@app.post("/admin/exams/<int:eid>/delete")
@need("admin")
def delexam(eid):
 with db() as c: c.execute("DELETE FROM exams WHERE id=?",(eid,))
 flash("تم حذف الامتحان ونتائجه"); return redirect(url_for("exams"))
@app.route("/admin/homework",methods=["GET","POST"])
@need("admin")
def homework():
 if request.method=="POST":
  pdf=request.files.get("pdf"); saved=""
  if pdf and pdf.filename:
   if not pdf.filename.lower().endswith(".pdf"): flash("ارفع ملف PDF فقط","error"); return redirect(url_for("homework"))
   saved=uuid.uuid4().hex+"_"+secure_filename(pdf.filename); pdf.save(os.path.join(HERE,"uploads",saved))
  with db() as c: c.execute("INSERT INTO homework(title,description,grade,due,pdf,created) VALUES(?,?,?,?,?,?)",(request.form["title"].strip(),request.form["description"].strip(),request.form["grade"],request.form.get("due",""),saved,datetime.now().isoformat(timespec="minutes")))
  flash("تم نشر الواجب"); return redirect(url_for("homework"))
 with db() as c:
  hs=c.execute("SELECT * FROM homework ORDER BY id DESC").fetchall()
  subs=c.execute("SELECT s.*,u.name,h.title FROM submissions s JOIN users u ON u.id=s.student_id JOIN homework h ON h.id=s.homework_id ORDER BY s.id DESC").fetchall()
 return render_template("homework.html",hs=hs,subs=subs)
@app.route("/admin/homework/<int:hid>/edit",methods=["GET","POST"])
@need("admin")
def edithomework(hid):
 with db() as c:
  h=c.execute("SELECT * FROM homework WHERE id=?",(hid,)).fetchone()
  if not h: abort(404)
  if request.method=="POST":
   pdf=request.files.get("pdf"); saved=h["pdf"]
   if pdf and pdf.filename:
    if not pdf.filename.lower().endswith(".pdf"):
     flash("ارفع ملف PDF فقط","error"); return redirect(url_for("edithomework",hid=hid))
    saved=uuid.uuid4().hex+"_"+secure_filename(pdf.filename)
    pdf.save(os.path.join(HERE,"uploads",saved))
   c.execute("UPDATE homework SET title=?,description=?,grade=?,due=?,pdf=? WHERE id=?",
    (request.form["title"].strip(),request.form["description"].strip(),request.form["grade"],request.form.get("due",""),saved,hid))
   flash("تم تعديل الواجب")
   return redirect(url_for("homework"))
 return render_template("edit_homework.html",h=h)

@app.post("/admin/homework/<int:hid>/delete")
@need("admin")
def delhomework(hid):
 with db() as c:
  h=c.execute("SELECT pdf FROM homework WHERE id=?",(hid,)).fetchone(); c.execute("DELETE FROM homework WHERE id=?",(hid,))
 if h and h["pdf"]:
  try: os.remove(os.path.join(HERE,"uploads",h["pdf"]))
  except OSError: pass
 flash("تم حذف الواجب"); return redirect(url_for("homework"))
@app.route("/admin/results")
@need("admin")
def results():
 with db() as c: rows=c.execute("SELECT r.*,u.name,u.grade,e.title FROM results r JOIN users u ON u.id=r.student_id JOIN exams e ON e.id=r.exam_id ORDER BY r.id DESC").fetchall()
 return render_template("results.html",rows=rows)
@app.route("/admin/preview")
@need("admin")
def preview():
 with db() as c: u=c.execute("SELECT * FROM users WHERE role='student' ORDER BY id LIMIT 1").fetchone()
 if not u: flash("أضيفي طالبًا أولًا","error"); return redirect(url_for("students"))
 session.update(uid=u["id"],username=u["username"],name=u["name"],role="student",grade=u["grade"],preview=True)
 return redirect(url_for("student"))
@app.route("/student/return")
@need("student")
def return_admin():
 if session.pop("preview",False):
  with db() as c: u=c.execute("SELECT * FROM users WHERE role='admin' LIMIT 1").fetchone()
  session.update(uid=u["id"],username=u["username"],name=u["name"],role="admin",grade="")
  return redirect(url_for("admin"))
 return redirect(url_for("student"))
@app.route("/student")
@need("student")
def student():
 with db() as c:
  es=c.execute("SELECT e.*,COUNT(q.id) n FROM exams e LEFT JOIN questions q ON q.exam_id=e.id WHERE e.grade=? GROUP BY e.id",(session["grade"],)).fetchall()
  hs=c.execute("SELECT * FROM homework WHERE grade=? ORDER BY id DESC",(session["grade"],)).fetchall()
  done=[x["homework_id"] for x in c.execute("SELECT homework_id FROM submissions WHERE student_id=?",(session["uid"],))]
  rs=c.execute("SELECT r.*,e.title FROM results r JOIN exams e ON e.id=r.exam_id WHERE r.student_id=?",(session["uid"],)).fetchall()
 return render_template("student.html",es=es,hs=hs,done=done,rs=rs)
@app.route("/student/exam/<int:eid>",methods=["GET","POST"])
@need("student")
def take(eid):
 with db() as c:
  e=c.execute("SELECT * FROM exams WHERE id=? AND grade=?",(eid,session["grade"])).fetchone()
  if not e: abort(404)
  qs=c.execute("SELECT * FROM questions WHERE exam_id=?",(eid,)).fetchall()
  prev=c.execute("SELECT id FROM results WHERE exam_id=? AND student_id=?",(eid,session["uid"])).fetchone()
  if request.method=="POST":
   if prev: flash("أديت هذا الامتحان من قبل","error"); return redirect(url_for("student"))
   score=0; total=0
   for q in qs:
    total+=q["points"]
    if request.form.get("q"+str(q["id"]))==q["correct"]: score+=q["points"]
   c.execute("INSERT INTO results(exam_id,student_id,score,total,submitted) VALUES(?,?,?,?,?)",(eid,session["uid"],score,total,datetime.now().isoformat(timespec="minutes")))
   flash(f"تم التسليم. درجتك {score:g} من {total:g}"); return redirect(url_for("student"))
 if prev: flash("أديت هذا الامتحان من قبل","error"); return redirect(url_for("student"))
 return render_template("take.html",exam=e,qs=qs)
@app.post("/student/homework/<int:hid>")
@need("student")
def submit(hid):
 ans=request.form.get("answer","").strip()
 with db() as c:
  h=c.execute("SELECT id FROM homework WHERE id=? AND grade=?",(hid,session["grade"])).fetchone()
  if not h: abort(404)
  if ans:
   try: c.execute("INSERT INTO submissions(homework_id,student_id,answer,submitted) VALUES(?,?,?,?)",(hid,session["uid"],ans,datetime.now().isoformat(timespec="minutes"))); flash("تم تسليم الواجب")
   except sqlite3.IntegrityError: flash("سبق تسليم الواجب","error")
  else: flash("اكتب الإجابة أولًا","error")
 return redirect(url_for("student"))
@app.route("/uploads/<path:name>")
@need(None)
def upload(name):
 with db() as c: ok=c.execute("SELECT 1 FROM homework WHERE pdf=?",(name,)).fetchone()
 if not ok: abort(404)
 return send_from_directory(os.path.join(HERE,"uploads"),name)
@app.errorhandler(403)
def forbidden(e): return render_template("message.html",msg="ليس لديك صلاحية لهذه الصفحة."),403
@app.errorhandler(404)
def missing(e): return render_template("message.html",msg="الصفحة غير موجودة."),404
init()
if __name__=="__main__": app.run(host="127.0.0.1",port=5000,debug=False)
