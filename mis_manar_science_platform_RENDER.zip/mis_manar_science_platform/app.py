
import os, sqlite3, json, uuid, time
from functools import wraps
from flask import Flask, request, redirect, url_for, session, flash, render_template_string, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

APP_DIR = os.path.dirname(os.path.abspath(__file__))
# On Render, set DATA_DIR=/var/data and attach a persistent disk at /var/data.
# Locally, data remains beside app.py as before.
DATA_DIR = os.environ.get("DATA_DIR", APP_DIR)
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "platform.db")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "local-demo-secret-change-before-public-deployment")
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
ALLOWED = {"pdf"}

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL,
      grade TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS exams(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, grade TEXT NOT NULL,
      duration INTEGER NOT NULL DEFAULT 30, questions TEXT NOT NULL DEFAULT '[]',
      pdf_file TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS exam_results(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
      exam_id INTEGER NOT NULL, score REAL NOT NULL, total REAL NOT NULL,
      answers TEXT NOT NULL DEFAULT '{}', submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, exam_id),
      FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(exam_id) REFERENCES exams(id)
    );
    CREATE TABLE IF NOT EXISTS homework(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL,
      grade TEXT NOT NULL, due_date TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS homework_submissions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, homework_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
      answer TEXT DEFAULT '', file_name TEXT DEFAULT '', submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(homework_id) REFERENCES homework(id), FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    if not con.execute("SELECT id FROM users WHERE role='teacher'").fetchone():
        con.execute("INSERT INTO users(username,password,name,role) VALUES(?,?,?,?)",
                    ("admin", generate_password_hash("admin123"), "ميس منار جمال", "teacher"))
    if not con.execute("SELECT id FROM users WHERE username='student'").fetchone():
        con.execute("INSERT INTO users(username,password,name,role,grade) VALUES(?,?,?,?,?)",
                    ("student", generate_password_hash("student123"), "طالب تجريبي", "student", "الصف السادس الابتدائي"))
    con.commit(); con.close()

init_db()

def login_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return deco

def layout(title, body, **ctx):
    user = session.get("name")
    role = session.get("role")
    return render_template_string(BASE, title=title, body=render_template_string(body, **ctx),
                                  user=user, role=role, get_flashed_messages=get_flashed_messages)

from flask import get_flashed_messages

BASE = r"""
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{title}} | منصة ميس منار جمال للعلوم</title>
<style>
:root{--navy:#183153;--blue:#2878b9;--teal:#19a58b;--bg:#f3f6fb;--ink:#203047}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Tahoma,Arial,sans-serif;color:var(--ink)}
header{background:linear-gradient(120deg,#183153,#2878b9);color:white;padding:18px 5%;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
header h1{font-size:21px;margin:0}header a{color:white;text-decoration:none;margin:0 8px}
nav{background:white;padding:12px 5%;box-shadow:0 2px 8px #142b4812;display:flex;gap:15px;flex-wrap:wrap}
nav a{color:var(--navy);text-decoration:none;font-weight:bold;font-size:14px}
main{max-width:1100px;margin:26px auto;padding:0 16px}.card{background:white;border-radius:15px;padding:22px;margin-bottom:18px;box-shadow:0 5px 20px #1831530c}
h2{color:var(--navy);margin-top:0;font-size:21px}h3{color:var(--navy)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px}
.stat{background:#eaf3fc;border-radius:12px;padding:18px}.stat b{display:block;font-size:28px;color:var(--blue);margin-top:8px}
input,select,textarea{width:100%;padding:12px;border:1px solid #d6deea;border-radius:9px;margin:7px 0 13px;font:inherit;background:white}
textarea{min-height:100px}label{font-weight:bold;font-size:14px}
button,.btn{border:0;background:var(--blue);color:white;padding:11px 17px;border-radius:9px;cursor:pointer;text-decoration:none;display:inline-block;font:inherit}
button.green,.btn.green{background:var(--teal)}button.red,.btn.red{background:#c94c58}button.gray,.btn.gray{background:#64748b}
table{width:100%;border-collapse:collapse}th,td{padding:11px;border-bottom:1px solid #e6ebf2;text-align:right;vertical-align:top}th{background:#f5f8fc}
.notice{padding:12px;border-radius:9px;background:#e8f6f2;margin:10px 0}.error{background:#fff0f0}.muted{color:#68788d;font-size:13px}
.question{padding:15px;background:#f7f9fc;border-radius:10px;margin:12px 0}
footer{text-align:center;color:#7b8797;padding:25px;font-size:13px}
@media(max-width:600px){header h1{font-size:17px}main{margin:15px auto}.card{padding:16px}table{font-size:13px}}
</style></head><body>
<header><h1>🔬 منصة ميس منار جمال للعلوم</h1>
<div>{% if user %}مرحباً، {{user}} · <a href="{{url_for('logout')}}">تسجيل الخروج</a>{% else %}<a href="{{url_for('login')}}">تسجيل الدخول</a>{% endif %}</div></header>
{% if user %}<nav>
{% if role=='teacher' %}
<a href="{{url_for('teacher')}}">الرئيسية</a><a href="{{url_for('exams_admin')}}">الامتحانات</a><a href="{{url_for('homework_admin')}}">الواجبات</a><a href="{{url_for('students')}}">الطلاب</a><a href="{{url_for('results')}}">النتائج والتسليمات</a><a href="{{url_for('preview')}}">معاينة الطالب</a>
{% else %}
<a href="{{url_for('student_home')}}">صفحتي</a>
{% endif %}</nav>{% endif %}
<main>{% for m in get_flashed_messages() %}<div class="notice">{{m}}</div>{% endfor %}{{body|safe}}</main>
<footer>منصة تعليمية تجريبية لمادة العلوم · البيانات محفوظة محلياً على هذا الكمبيوتر</footer></body></html>
"""

@app.route("/")
def index():
    return redirect(url_for("teacher") if session.get("role")=="teacher" else url_for("student_home") if session.get("role")=="student" else url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        con=db(); u=con.execute("SELECT * FROM users WHERE username=?",(request.form["username"].strip(),)).fetchone(); con.close()
        if u and check_password_hash(u["password"],request.form["password"]):
            session.update(user_id=u["id"],name=u["name"],role=u["role"],grade=u["grade"])
            return redirect(url_for("teacher" if u["role"]=="teacher" else "student_home"))
        flash("اسم المستخدم أو كلمة المرور غير صحيحة.")
    body="""<div class="card" style="max-width:470px;margin:35px auto"><h2>تسجيل الدخول</h2>
    <form method="post"><label>اسم المستخدم</label><input name="username" required>
    <label>كلمة المرور</label><input type="password" name="password" required><button class="green">دخول</button></form>
    <hr><p class="muted">حساب المدرّسة: admin / admin123</p><p class="muted">حساب الطالب: student / student123</p></div>"""
    return layout("تسجيل الدخول",body)

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/teacher")
@login_required("teacher")
def teacher():
    con=db()
    counts=[con.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0],
            con.execute("SELECT COUNT(*) FROM exams").fetchone()[0],
            con.execute("SELECT COUNT(*) FROM homework").fetchone()[0],
            con.execute("SELECT COUNT(*) FROM exam_results").fetchone()[0]]
    con.close()
    body="""<div class="card"><h2>لوحة تحكم المدرّسة</h2><p>أهلاً بكِ في منصة ميس منار جمال للعلوم. يمكنك إدارة المحتوى والطلاب ومتابعة الأداء من هنا.</p>
    <div class="grid">{% for label,n in [('الطلاب',counts[0]),('الامتحانات',counts[1]),('الواجبات',counts[2]),('محاولات الامتحان',counts[3])] %}<div class="stat">{{label}}<b>{{n}}</b></div>{% endfor %}</div></div>
    <div class="grid"><div class="card"><h3>📝 الامتحانات</h3><p>إنشاء امتحان بأسئلة واختيارات ودرجات ووقت أو رفع PDF.</p><a class="btn" href="{{url_for('exams_admin')}}">إدارة الامتحانات</a></div>
    <div class="card"><h3>📚 الواجبات</h3><p>إضافة الواجبات وتعديلها وحذفها ومراجعة التسليمات.</p><a class="btn" href="{{url_for('homework_admin')}}">إدارة الواجبات</a></div>
    <div class="card"><h3>👩‍🎓 الطلاب</h3><p>إضافة حسابات الطلاب وتحديد الصف الدراسي.</p><a class="btn" href="{{url_for('students')}}">إدارة الطلاب</a></div>
    <div class="card"><h3>📊 النتائج</h3><p>عرض الدرجات ومتابعة تسليمات الطلاب.</p><a class="btn" href="{{url_for('results')}}">عرض النتائج</a></div></div>"""
    return layout("لوحة المدرّسة",body,counts=counts)

def parse_questions(raw):
    # one question per line: question|option1|option2|option3|option4|correct(1-4)|points
    qs=[]
    for line in raw.splitlines():
        if not line.strip(): continue
        p=[x.strip() for x in line.split("|")]
        if len(p)!=7: raise ValueError("كل سؤال يجب أن يحتوي على 7 أجزاء مفصولة بعلامة |")
        q, *rest=p; opts=rest[:4]; correct=int(rest[4]); points=float(rest[5])
        if correct not in (1,2,3,4) or points<=0 or not q or any(not x for x in opts): raise ValueError("راجع نص السؤال والاختيارات ورقم الإجابة والدرجة.")
        qs.append({"q":q,"options":opts,"correct":correct-1,"points":points})
    return qs

@app.route("/teacher/exams",methods=["GET","POST"])
@login_required("teacher")
def exams_admin():
    con=db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); grade=request.form.get("grade","").strip()
        duration=max(1,int(request.form.get("duration",30)))
        pdf=request.files.get("pdf"); pdf_name=""
        if pdf and pdf.filename:
            if not pdf.filename.lower().endswith(".pdf"):
                flash("يسمح برفع ملفات PDF فقط."); con.close(); return redirect(url_for("exams_admin"))
            pdf_name=uuid.uuid4().hex+"_"+secure_filename(pdf.filename)
            pdf.save(os.path.join(UPLOAD_DIR,pdf_name))
        try: qs=parse_questions(request.form.get("questions","")) if request.form.get("questions","").strip() else []
        except Exception as e:
            flash(str(e)); con.close(); return redirect(url_for("exams_admin"))
        if not title or not grade: flash("اكتب اسم الامتحان والصف الدراسي.")
        elif not qs and not pdf_name: flash("أضف أسئلة أو ارفع ملف PDF.")
        else:
            con.execute("INSERT INTO exams(title,grade,duration,questions,pdf_file) VALUES(?,?,?,?,?)",
                        (title,grade,duration,json.dumps(qs,ensure_ascii=False),pdf_name)); con.commit(); flash("تم حفظ الامتحان.")
        con.close(); return redirect(url_for("exams_admin"))
    rows=con.execute("SELECT * FROM exams ORDER BY id DESC").fetchall(); con.close()
    body="""<div class="card"><h2>إضافة امتحان جديد</h2>
    <form method="post" enctype="multipart/form-data"><div class="grid"><div><label>اسم الامتحان</label><input name="title" required></div>
    <div><label>الصف الدراسي</label><select name="grade" required>{% for g in grades %}<option>{{g}}</option>{% endfor %}</select></div>
    <div><label>الوقت بالدقائق</label><input type="number" name="duration" value="30" min="1" required></div></div>
    <label>الأسئلة (سؤال في كل سطر)</label><textarea name="questions" placeholder="ما مصدر الطاقة الرئيسي للأرض؟|الشمس|القمر|النجوم|الرياح|1|2"></textarea>
    <p class="muted">الصيغة: السؤال|اختيار1|اختيار2|اختيار3|اختيار4|رقم الإجابة الصحيحة (1-4)|الدرجة. اترك الحقل فارغاً إذا كنت سترفع PDF فقط.</p>
    <label>رفع امتحان PDF (اختياري)</label><input type="file" name="pdf" accept="application/pdf">
    <button class="green">حفظ الامتحان</button></form></div>
    <div class="card"><h2>الامتحانات الحالية</h2>{% if rows %}<table><tr><th>الامتحان</th><th>الصف</th><th>الوقت</th><th>المحتوى</th><th></th></tr>
    {% for e in rows %}<tr><td>{{e.title}}</td><td>{{e.grade}}</td><td>{{e.duration}} دقيقة</td><td>{% if e.pdf_file %}<a href="{{url_for('uploaded',filename=e.pdf_file)}}" target="_blank">ملف PDF</a>{% endif %} {% if e.questions!='[]' %}أسئلة تفاعلية{% endif %}</td>
    <td><form method="post" action="{{url_for('delete_exam',id=e.id)}}" onsubmit="return confirm('حذف الامتحان؟')"><button class="red">حذف</button></form></td></tr>{% endfor %}</table>{% else %}<p>لا توجد امتحانات بعد.</p>{% endif %}</div>"""
    return layout("إدارة الامتحانات",body,rows=rows,grades=GRADES)

@app.post("/teacher/exams/<int:id>/delete")
@login_required("teacher")
def delete_exam(id):
    con=db(); e=con.execute("SELECT pdf_file FROM exams WHERE id=?",(id,)).fetchone()
    if e:
        con.execute("DELETE FROM exam_results WHERE exam_id=?",(id,)); con.execute("DELETE FROM exams WHERE id=?",(id,)); con.commit()
        if e["pdf_file"]:
            try: os.remove(os.path.join(UPLOAD_DIR,e["pdf_file"]))
            except: pass
    con.close(); flash("تم حذف الامتحان."); return redirect(url_for("exams_admin"))

@app.route("/teacher/homework",methods=["GET","POST"])
@login_required("teacher")
def homework_admin():
    con=db()
    if request.method=="POST":
        action=request.form.get("action")
        if action=="delete":
            con.execute("DELETE FROM homework_submissions WHERE homework_id=?",(request.form["id"],))
            con.execute("DELETE FROM homework WHERE id=?",(request.form["id"],)); con.commit(); flash("تم حذف الواجب.")
        else:
            con.execute("INSERT INTO homework(title,description,grade,due_date) VALUES(?,?,?,?)",
                        (request.form["title"],request.form["description"],request.form["grade"],request.form.get("due_date","")))
            con.commit(); flash("تمت إضافة الواجب.")
        con.close(); return redirect(url_for("homework_admin"))
    rows=con.execute("SELECT * FROM homework ORDER BY id DESC").fetchall(); con.close()
    body="""<div class="card"><h2>إضافة واجب</h2><form method="post"><label>عنوان الواجب</label><input name="title" required>
    <label>التعليمات</label><textarea name="description" required></textarea><div class="grid"><div><label>الصف</label><select name="grade">{% for g in grades %}<option>{{g}}</option>{% endfor %}</select></div>
    <div><label>آخر موعد (اختياري)</label><input type="date" name="due_date"></div></div><button class="green">إضافة الواجب</button></form></div>
    <div class="card"><h2>الواجبات المنشورة</h2>{% for h in rows %}<div class="question"><b>{{h.title}}</b> — {{h.grade}} <p>{{h.description}}</p><span class="muted">آخر موعد: {{h.due_date or 'غير محدد'}}</span> <a class="btn gray" href="{{url_for('edit_homework',id=h.id)}}">تعديل</a>
    <form method="post" style="display:inline"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="{{h.id}}"><button class="red">حذف</button></form></div>{% else %}<p>لا توجد واجبات.</p>{% endfor %}</div>"""
    return layout("إدارة الواجبات",body,rows=rows,grades=GRADES)

@app.route("/teacher/homework/<int:id>/edit",methods=["GET","POST"])
@login_required("teacher")
def edit_homework(id):
    con=db(); h=con.execute("SELECT * FROM homework WHERE id=?",(id,)).fetchone()
    if not h: con.close(); abort(404)
    if request.method=="POST":
        con.execute("UPDATE homework SET title=?,description=?,grade=?,due_date=? WHERE id=?",
                     (request.form["title"],request.form["description"],request.form["grade"],request.form.get("due_date",""),id))
        con.commit(); con.close(); flash("تم تعديل الواجب."); return redirect(url_for("homework_admin"))
    con.close()
    body="""<div class="card"><h2>تعديل الواجب</h2><form method="post"><label>عنوان الواجب</label><input name="title" value="{{h.title}}" required><label>التعليمات</label><textarea name="description" required>{{h.description}}</textarea><label>الصف</label><select name="grade">{% for g in grades %}<option {% if g==h.grade %}selected{% endif %}>{{g}}</option>{% endfor %}</select><label>آخر موعد</label><input type="date" name="due_date" value="{{h.due_date}}"><button class="green">حفظ التعديلات</button> <a class="btn gray" href="{{url_for('homework_admin')}}">رجوع</a></form></div>"""
    return layout("تعديل واجب",body,h=h,grades=GRADES)

GRADES=["الصف الرابع الابتدائي","الصف الخامس الابتدائي","الصف السادس الابتدائي","الصف الأول الإعدادي","الصف الثاني الإعدادي","الصف الثالث الإعدادي"]

@app.route("/teacher/students",methods=["GET","POST"])
@login_required("teacher")
def students():
    con=db()
    if request.method=="POST":
        try:
            con.execute("INSERT INTO users(username,password,name,role,grade) VALUES(?,?,?,?,?)",
                        (request.form["username"].strip(),generate_password_hash(request.form["password"]),request.form["name"].strip(),"student",request.form["grade"]))
            con.commit(); flash("تم إنشاء حساب الطالب.")
        except sqlite3.IntegrityError: flash("اسم المستخدم مستخدم بالفعل.")
        con.close(); return redirect(url_for("students"))
    rows=con.execute("SELECT id,username,name,grade FROM users WHERE role='student' ORDER BY grade,name").fetchall(); con.close()
    body="""<div class="card"><h2>إضافة طالب</h2><form method="post"><div class="grid"><div><label>اسم الطالب</label><input name="name" required></div><div><label>اسم المستخدم</label><input name="username" required></div>
    <div><label>كلمة المرور</label><input name="password" required></div><div><label>الصف الدراسي</label><select name="grade">{% for g in grades %}<option>{{g}}</option>{% endfor %}</select></div></div><button class="green">إضافة الطالب</button></form></div>
    <div class="card"><h2>قائمة الطلاب</h2><table><tr><th>الاسم</th><th>اسم المستخدم</th><th>الصف</th><th></th></tr>{% for s in rows %}<tr><td>{{s.name}}</td><td>{{s.username}}</td><td>{{s.grade}}</td><td><form method="post" action="{{url_for('delete_student',id=s.id)}}" onsubmit="return confirm('حذف الطالب؟')"><button class="red">حذف</button></form></td></tr>{% else %}<tr><td colspan="4">لا يوجد طلاب.</td></tr>{% endfor %}</table></div>"""
    return layout("إدارة الطلاب",body,rows=rows,grades=GRADES)

@app.post("/teacher/students/<int:id>/delete")
@login_required("teacher")
def delete_student(id):
    con=db(); con.execute("DELETE FROM exam_results WHERE user_id=?",(id,)); con.execute("DELETE FROM homework_submissions WHERE user_id=?",(id,)); con.execute("DELETE FROM users WHERE id=? AND role='student'",(id,)); con.commit(); con.close()
    flash("تم حذف الطالب."); return redirect(url_for("students"))

@app.route("/teacher/results")
@login_required("teacher")
def results():
    con=db()
    exams=con.execute("""SELECT r.*,u.name student,e.title exam FROM exam_results r JOIN users u ON u.id=r.user_id JOIN exams e ON e.id=r.exam_id ORDER BY r.submitted_at DESC""").fetchall()
    subs=con.execute("""SELECT s.*,u.name student,h.title homework FROM homework_submissions s JOIN users u ON u.id=s.user_id JOIN homework h ON h.id=s.homework_id ORDER BY s.submitted_at DESC""").fetchall()
    con.close()
    body="""<div class="card"><h2>نتائج الامتحانات</h2><table><tr><th>الطالب</th><th>الامتحان</th><th>الدرجة</th><th>تاريخ التسليم</th></tr>{% for r in exams %}<tr><td>{{r.student}}</td><td>{{r.exam}}</td><td>{{r.score}} / {{r.total}}</td><td>{{r.submitted_at}}</td></tr>{% else %}<tr><td colspan="4">لا توجد نتائج بعد.</td></tr>{% endfor %}</table></div>
    <div class="card"><h2>تسليمات الواجبات</h2><table><tr><th>الطالب</th><th>الواجب</th><th>الإجابة</th><th>ملف</th><th>التاريخ</th></tr>{% for s in subs %}<tr><td>{{s.student}}</td><td>{{s.homework}}</td><td>{{s.answer}}</td><td>{% if s.file_name %}<a href="{{url_for('uploaded',filename=s.file_name)}}" target="_blank">فتح الملف</a>{% endif %}</td><td>{{s.submitted_at}}</td></tr>{% else %}<tr><td colspan="5">لا توجد تسليمات.</td></tr>{% endfor %}</table></div>"""
    return layout("النتائج والتسليمات",body,exams=exams,subs=subs)

@app.route("/teacher/preview")
@login_required("teacher")
def preview():
    return redirect(url_for("student_home",preview=1))

@app.route("/student")
@login_required()
def student_home():
    if session.get("role") not in ("student","teacher"): abort(403)
    grade=session.get("grade") or ""
    con=db()
    exams=con.execute("SELECT * FROM exams WHERE grade=? OR ?='teacher' ORDER BY id DESC",(grade,session.get("role"))).fetchall()
    hw=con.execute("SELECT * FROM homework WHERE grade=? OR ?='teacher' ORDER BY id DESC",(grade,session.get("role"))).fetchall()
    con.close()
    body="""<div class="card"><h2>مساحة الطالب</h2><p>الصف الدراسي: {{grade or 'معاينة المدرّسة'}}</p><p>اختر امتحاناً أو واجباً من القائمة.</p></div>
    <div class="card"><h2>الامتحانات</h2>{% for e in exams %}<div class="question"><b>{{e.title}}</b> · {{e.duration}} دقيقة {% if e.pdf_file %}<p><a href="{{url_for('uploaded',filename=e.pdf_file)}}" target="_blank">فتح امتحان PDF</a></p>{% endif %}{% if e.questions!='[]' %}<a class="btn" href="{{url_for('take_exam',id=e.id)}}">بدء الامتحان</a>{% endif %}</div>{% else %}<p>لا توجد امتحانات متاحة لهذا الصف.</p>{% endfor %}</div>
    <div class="card"><h2>الواجبات</h2>{% for h in hw %}<div class="question"><b>{{h.title}}</b><p>{{h.description}}</p><span class="muted">آخر موعد: {{h.due_date or 'غير محدد'}}</span><a class="btn" href="{{url_for('submit_homework',id=h.id)}}">تسليم الواجب</a></div>{% else %}<p>لا توجد واجبات لهذا الصف.</p>{% endfor %}</div>"""
    return layout("مساحة الطالب",body,grade=grade,exams=exams,hw=hw)

@app.route("/student/exam/<int:id>",methods=["GET","POST"])
@login_required()
def take_exam(id):
    con=db(); e=con.execute("SELECT * FROM exams WHERE id=?",(id,)).fetchone()
    if not e: con.close(); abort(404)
    if session.get("role")=="student" and e["grade"]!=session.get("grade"): con.close(); abort(403)
    qs=json.loads(e["questions"])
    if not qs: con.close(); flash("هذا الامتحان مرفوع بصيغة PDF فقط ولا يدعم التصحيح التلقائي."); return redirect(url_for("student_home"))
    previous=con.execute("SELECT id FROM exam_results WHERE user_id=? AND exam_id=?",(session["user_id"],id)).fetchone()
    if previous: con.close(); flash("سبق لك تسليم هذا الامتحان."); return redirect(url_for("student_home"))
    if request.method=="POST":
        score=0; total=sum(float(q["points"]) for q in qs); answers={}
        for i,q in enumerate(qs):
            ans=request.form.get("q"+str(i),"")
            answers[str(i)]=ans
            if ans.isdigit() and int(ans)==q["correct"]: score+=float(q["points"])
        con.execute("INSERT INTO exam_results(user_id,exam_id,score,total,answers) VALUES(?,?,?,?,?)",
                    (session["user_id"],id,score,total,json.dumps(answers)))
        con.commit(); con.close(); flash(f"تم تسليم الامتحان. نتيجتك: {score:g} من {total:g}")
        return redirect(url_for("student_home"))
    con.close()
    body="""<div class="card"><h2>{{exam.title}}</h2><p>الوقت المتبقي: <strong id="countdown">{{exam.duration}}:00</strong></p>
    <form method="post" id="examForm">{% for q in qs %}{% set qi=loop.index0 %}<div class="question"><b>{{loop.index}}. {{q.q}} ({{q.points}} درجة)</b>{% for op in q.options %}<label style="display:block;font-weight:normal"><input style="width:auto;margin:9px" type="radio" name="q{{qi}}" value="{{loop.index0}}" required>{{op}}</label>{% endfor %}</div>{% endfor %}<button class="green" onclick="return confirm('تأكيد تسليم الامتحان؟')">تسليم الامتحان</button></form>
    <script>(function(){let left={{exam.duration}}*60;const el=document.getElementById('countdown');const form=document.getElementById('examForm');function tick(){let m=Math.floor(left/60),s=left%60;el.textContent=m+':'+String(s).padStart(2,'0');if(left<=0){alert('انتهى وقت الامتحان وسيتم تسليم إجاباتك.');form.submit();return;}left--;setTimeout(tick,1000);}tick();})();</script></div>"""
    return layout("حل الامتحان",body,exam=e,qs=qs)

@app.route("/student/homework/<int:id>",methods=["GET","POST"])
@login_required()
def submit_homework(id):
    con=db(); h=con.execute("SELECT * FROM homework WHERE id=?",(id,)).fetchone()
    if not h: con.close(); abort(404)
    if session.get("role")=="student" and h["grade"]!=session.get("grade"): con.close(); abort(403)
    if request.method=="POST":
        f=request.files.get("attachment"); fname=""
        if f and f.filename:
            if not f.filename.lower().endswith(".pdf"): flash("المرفق يجب أن يكون PDF."); con.close(); return redirect(url_for("submit_homework",id=id))
            fname=uuid.uuid4().hex+"_"+secure_filename(f.filename); f.save(os.path.join(UPLOAD_DIR,fname))
        con.execute("INSERT INTO homework_submissions(homework_id,user_id,answer,file_name) VALUES(?,?,?,?)",
                    (id,session["user_id"],request.form.get("answer",""),fname)); con.commit(); con.close()
        flash("تم إرسال الواجب."); return redirect(url_for("student_home"))
    con.close()
    body="""<div class="card"><h2>{{h.title}}</h2><p>{{h.description}}</p><form method="post" enctype="multipart/form-data"><label>إجابتك</label><textarea name="answer" placeholder="اكتب إجابتك هنا"></textarea><label>إرفاق ملف PDF (اختياري)</label><input type="file" name="attachment" accept="application/pdf"><button class="green">إرسال الواجب</button></form></div>"""
    return layout("تسليم واجب",body,h=h)

@app.route("/uploads/<path:filename>")
@login_required()
def uploaded(filename):
    # Only serve files actually present in upload folder.
    return send_from_directory(UPLOAD_DIR,filename,as_attachment=False)

@app.errorhandler(403)
def forbidden(e): return layout("غير مسموح","<div class='card'><h2>ليس لديك صلاحية لفتح هذه الصفحة.</h2></div>"),403

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT", 5000)),debug=False)
